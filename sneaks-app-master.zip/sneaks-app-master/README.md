# Sneaks App
The [Sneaks App](https://druv5319.github.io/sneaks-app/) is a React website that allows users to search sneakers, get product information and compare prices from StockX, Flight Club, Goat and Stadium Goods through the [Sneaks API](https://github.com/druv5319/Sneaks-API)
## Demo
#### Sneaks App - [https://Sneaks-App.com](https://sneaks-app.com)

<img src="https://github.com/druv5319/Sneaks-API/blob/master/Screenshots/demo.gif" width=800 align=left>


